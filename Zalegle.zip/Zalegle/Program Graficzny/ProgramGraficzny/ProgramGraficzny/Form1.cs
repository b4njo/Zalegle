﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramGraficzny
{
    public partial class Form1 : Form
    {
        bool drawing = false;
        bool draw = true;
        bool erease = false;
        Graphics graphic1;
        Pen LeftPen = new Pen(Color.Green, 18);
        Pen RightPen = new Pen(Color.Red, 14);
        Pen Ereaser = new Pen(Color.White, 20);
        int x0, y0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            drawing = true;
            x0 = e.X;
            y0 = e.Y;
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            drawing = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (draw == true)
            {
                if (drawing == true)
                {
                    if (e.Button == MouseButtons.Left)
                    {
                        int x = e.X; int y = e.Y;
                        graphic1.DrawLine(LeftPen, x0, y0, x, y);
                        x0 = x; y0 = y;
                    }

                    if (e.Button == MouseButtons.Right)
                    {
                        int x = e.X; int y = e.Y;
                        graphic1.DrawLine(RightPen, x0, y0, x, y);
                        x0 = x; y0 = y;
                    }
                }
            }

            else
            {
                if (drawing == true)
                {
                    int x = e.X; int y = e.Y;
                    graphic1.DrawLine(Ereaser, x0, y0, x, y);
                    x0 = x; y0 = y;
                }
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            erease = true;
            draw = false;
            label1.Text = "Ereaser";
        }

        private void toolStripButton2_CheckStateChanged(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            erease = false;
            draw = true;
            label1.Text = "Drawer";
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.Invalidate();
            erease = false;
            draw = true;
            label1.Text = "Drawer";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            graphic1 = this.CreateGraphics();
        }


    }
}
