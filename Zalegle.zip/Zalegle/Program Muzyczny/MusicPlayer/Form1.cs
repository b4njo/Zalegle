﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MusicPlayer
{
    public partial class Form1 : Form
    {
        private WMPLib.WindowsMediaPlayer wplayer = new WMPLib.WindowsMediaPlayer();
        string myFilePath="none";
        bool isPlaying = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    myFilePath = openFileDialog1.FileName;
                    wplayer.URL = myFilePath;
                    wplayer.controls.play();
                    playPauseButton.BackgroundImage = Image.FromFile(@"Buttons\pause.jpg");
                    isPlaying = true;
                }    
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Form1", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void playPauseButton_Click(object sender, EventArgs e)
        {
            if (myFilePath != "none")
            {
                if (isPlaying == true)
                {
                    wplayer.controls.pause();
                    isPlaying = false;
                    playPauseButton.BackgroundImage = Image.FromFile(@"Buttons\play.jpg");
                }

                else
                {
                    wplayer.controls.play();
                    isPlaying = true;
                    playPauseButton.BackgroundImage = Image.FromFile(@"Buttons\pause.jpg");
                }
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            wplayer.controls.stop();
            isPlaying = false;
            playPauseButton.BackgroundImage = Image.FromFile(@"Buttons\play.jpg");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string myDirectory;
            myDirectory = Application.StartupPath + @"\SampleMusic";
            openFileDialog1.InitialDirectory = myDirectory;
        }
    }
}
